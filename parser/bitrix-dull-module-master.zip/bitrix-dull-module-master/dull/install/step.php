<?if(!check_bitrix_sessid()) return;?>
<?
echo CAdminMessage::ShowNote("Модуль dull установлен");
?>