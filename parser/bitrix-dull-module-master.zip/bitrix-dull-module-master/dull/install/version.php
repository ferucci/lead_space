<?
$arModuleVersion = array(
    "VERSION" => "1.0.0",
    "VERSION_DATE" => "2013-09-23 15:00:00"
);