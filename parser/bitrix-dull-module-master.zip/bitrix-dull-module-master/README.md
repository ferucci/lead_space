bitrix-dull-module
==================

Empty module for 1C-Bitrix
